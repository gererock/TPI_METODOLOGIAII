# Guia completa del frontend HTML + JS

## 1. Mapa general del proyecto

### Paginas HTML principales
- `pages/CatalogoCliente.html`: arma la estructura visual del catalogo, el carrito flotante y el modal para agregar productos.
- `pages/CarritoCliente.html`: arma la pantalla final de compra y el modal de pago en efectivo.
- `pages/Admin.html`: arma la pantalla del administrador para crear y listar productos.
- `pages/RegistrarCliente.html`: arma la pantalla de registro de cliente.

### JS principales
- `js/productos-api.js`: modulo base que habla con el backend para traer productos y dar utilidades compartidas.
- `js/cart-store.js`: modulo de carrito. No habla directo con el backend. Guarda el carrito en `localStorage` y calcula stock reservado/comprado.
- `js/catalogo.js`: logica del catalogo. Carga productos desde backend usando `productos-api.js`, dibuja la grilla, el modal y el carrito.
- `js/checkout.js`: logica del checkout. Usa productos + carrito para armar el resumen final y confirmar el pago.
- `js/ApiAdmin.js`: JS del admin. Habla con el backend para listar y crear productos.
- `js/RegistrarClienteApi.js`: JS del registro. Habla con el backend para registrar clientes.

---

## 2. Donde se conecta con el backend

Esta es la parte mas importante para unir front y back.

### Conexion directa al backend

#### `js/productos-api.js`
- Linea 3: define la base del backend:
  - `const URL_API = "http://localhost:8080";`
- Linea 14: hace `GET` al backend para pedir productos:
  - ``fetch(`${URL_API}/api/productos?page=0&size=100`)``

#### `js/ApiAdmin.js`
- Linea 142: hace `GET` para traer productos al panel admin:
  - ``fetch(`${URL_API}/api/productos?page=0&size=100`)``
- Lineas 173 a 176: hace `POST` para crear un producto:
  - URL: `/api/productos`
  - Metodo: `POST`
  - Headers: `Content-Type: application/json`
  - Body: `JSON.stringify(producto)`

#### `js/RegistrarClienteApi.js`
- Lineas 139 a 143: hace `POST` para registrar cliente:
  - URL: `/api/clientes/register`
  - Metodo: `POST`
  - Headers: `Content-Type: application/json`
  - Body: `JSON.stringify(cliente)`

### Conexion indirecta con el backend

#### `js/catalogo.js`
- Linea 526:
  - `estado.productos = await obtenerProductos();`
- No llama al backend directamente.
- Llama a `obtenerProductos()` que vive en `productos-api.js`.
- O sea:
  - `catalogo.js` -> `productos-api.js` -> backend

#### `js/checkout.js`
- Linea 120:
  - `estado.productos = await obtenerProductos();`
- Igual que el catalogo:
  - `checkout.js` -> `productos-api.js` -> backend

### Importante
- `js/cart-store.js` **no** se conecta al backend.
- Ese archivo maneja carrito y stock reservado/comprado en el navegador usando `localStorage`.
- Si mas adelante queres persistir carrito en backend, el archivo a tocar primero seria `cart-store.js`.

---

## 3. Explicacion de `pages/CatalogoCliente.html`

### Lineas 1 a 15
| Lineas | Que hacen |
|---|---|
| 1 | `<!DOCTYPE html>` le dice al navegador que el documento es HTML5. |
| 2 | `<html lang="es">` abre la pagina y marca que el idioma es español. |
| 3 a 15 | `<head>` contiene metadatos, links a fuentes, CSS y el JS principal de la pagina. |
| 4 | `<meta charset="UTF-8" />` permite usar caracteres especiales. |
| 5 | `<meta name="viewport"...>` hace que la pagina responda bien en celular. |
| 6 | `<title>BodyPaint - Catalogo</title>` es el texto de la pestaña del navegador. |
| 7 y 8 | `preconnect` acelera la conexion con Google Fonts. |
| 9 a 12 | carga las fuentes Barlow y Barlow Condensed. |
| 13 | carga `catalogo.css`. |
| 14 | carga `catalogo.js` como modulo ES. `type="module"` permite usar `import/export`. |

### Lineas 17 a 84: navbar y carrito
| Lineas | Que hacen |
|---|---|
| 18 | `<nav class="navbar">` abre la barra de navegacion. |
| 19 | logo de la marca. |
| 21 a 26 | lista de links de navegacion. |
| 28 a 31 | boton/link para entrar al panel admin. |
| 33 a 50 | boton que abre el carrito. |
| 36 | `id="cart-toggle"` permite que JS encuentre ese boton. |
| 38 | `aria-expanded="false"` arranca diciendo que el panel esta cerrado. Es accesibilidad. |
| 39 | `aria-controls="cart-panel"` dice que este boton controla el bloque con id `cart-panel`. |
| 49 | `id="cart-count"` es el numero que JS actualiza con la cantidad del carrito. |
| 52 a 77 | `<aside>` es el panel desplegable del carrito. |
| 55 | `aria-hidden="true"` arranca oculto para lectores de pantalla. |
| 57 | `hidden` hace que empiece realmente oculto. |
| 60 | titulo del carrito. |
| 61 | boton X para cerrar. |
| 66 | contenedor donde JS inyecta los productos del carrito. |
| 71 | `id="cart-total"` es donde JS escribe el total. |
| 73 | `id="cart-continue"` es el boton que lleva al checkout. |

### Lineas 81 a 83
| Lineas | Que hacen |
|---|---|
| 81 a 83 | boton hamburguesa para responsive. En esta version no tiene logica JS asociada. |

### Lineas 86 a 115: hero y buscador
| Lineas | Que hacen |
|---|---|
| 87 a 93 | hero visual con titulo y subtitulo del catalogo. |
| 96 a 115 | zona del buscador. |
| 99 a 102 | SVG de la lupa. |
| 103 a 109 | input real de busqueda. |
| 104 | `id="search"` conecta este input con `catalogo.js`. |
| 110 a 112 | boton para limpiar la busqueda. `id="clear-btn"` tambien lo usa JS. |

### Lineas 117 a 169: grilla y modal
| Lineas | Que hacen |
|---|---|
| 118 | `<main id="catalog-grid">` es la grilla donde `catalogo.js` pinta todas las tarjetas. Arranca vacia. |
| 121 a 169 | modal del producto. Arranca oculto con `hidden`. |
| 124 | imagen del producto dentro del modal. |
| 125 | boton X del modal. |
| 131 | titulo del producto. |
| 132 | marca del producto. |
| 133 | descripcion del producto. |
| 136 | stock disponible del producto. |
| 137 | precio del producto. |
| 145 | boton para bajar cantidad a agregar. |
| 148 a 156 | input numérico con la cantidad elegida. |
| 157 | boton para subir cantidad. |
| 162 a 164 | boton final para agregar al carrito. |

---

## 4. Explicacion de `pages/CarritoCliente.html`

### Lineas 1 a 15
- Mismo rol que el `<head>` del catalogo, pero carga:
  - `checkout.css`
  - `checkout.js`

### Lineas 17 a 24
| Lineas | Que hacen |
|---|---|
| 18 a 24 | navbar simple con logo y link para volver al catalogo. |

### Lineas 26 a 34
| Lineas | Que hacen |
|---|---|
| 27 a 34 | hero visual del checkout. Solo aporta estructura visual y contexto. |

### Lineas 36 a 75: layout principal
| Lineas | Que hacen |
|---|---|
| 37 | `<main class="container checkout-layout">` divide la pantalla en columna principal + resumen lateral. |
| 38 a 49 | columna izquierda: lista de productos elegidos. |
| 42 | `id="order-number"` es el numero de pedido placeholder. |
| 47 | `id="checkout-items"` es donde JS inyecta los productos del resumen. |
| 51 a 74 | columna derecha: resumen de la compra. |
| 58 | `id="summary-items"` lo completa JS con la cantidad total. |
| 63 | `id="summary-total"` lo completa JS con el total de dinero. |
| 66 | `id="cash-payment-btn"` abre el modal de pago. |

### Lineas 77 a 88: modal de pago
| Lineas | Que hacen |
|---|---|
| 78 | overlay del modal, arranca oculto con `hidden`. |
| 81 | `id="payment-title"` lo actualiza JS con el monto total. |
| 84 | boton cancelar. |
| 85 | boton finalizar pago. |

---

## 5. Explicacion de `pages/Admin.html`

### Lineas 1 a 13
- Estructura del documento y carga de:
  - `CreateAdminProduct.css`
  - `ApiAdmin.js`

### Lineas 16 a 31
- Navbar del admin.
- La linea 26 tiene un link para volver al catalogo.

### Lineas 33 a 49
- Hero del panel admin.
- Barra de pestañas:
  - Linea 46: boton para abrir la pestaña de crear producto.
  - Linea 47: boton para abrir la pestaña de listado de productos.

### Lineas 51 a 115: formulario de alta
| Lineas | Que hacen |
|---|---|
| 54 | panel `tab-crear`, visible al inicio. |
| 74 a 79 | input de nombre y de marca. |
| 85 a 93 | input de precio y de stock. |
| 99 a 100 | input de URL de foto. |
| 105 a 106 | textarea de descripcion. |
| 111 | boton cancelar. |
| 112 | boton crear producto. |

### Lineas 117 a 143: tabla de productos
| Lineas | Que hacen |
|---|---|
| 117 | panel `tab-productos`, oculto al inicio. |
| 123 | boton para volver rapido a la pestaña de crear. |
| 126 a 141 | tabla donde JS mete los productos traidos del backend. |
| 136 | `id="products-tbody"` es el cuerpo de tabla que `ApiAdmin.js` reemplaza dinamicamente. |

### Linea 147
- `<div class="toast" id="toast"></div>` es el contenedor visual de mensajes cortos de exito o error.

---

## 6. Explicacion de `pages/RegistrarCliente.html`

### Lineas 1 a 13
- Estructura base y carga de:
  - `styleRegistro.css`
  - `RegistrarClienteApi.js`

### Lineas 16 a 31
- Navbar con link a iniciar sesion.

### Lineas 33 a 40
- Hero del registro.

### Lineas 43 a 127: formulario
| Lineas | Que hacen |
|---|---|
| 56 | `<form id="registro-form" novalidate>` crea el formulario y desactiva validacion nativa del navegador para usar la del JS. |
| 59 a 64 | inputs de nombre y apellido. |
| 70 a 75 | inputs de email y DNI. |
| 80 a 92 | input de contraseña con boton para mostrar/ocultar. |
| 98 a 103 | provincia y localidad. |
| 109 a 118 | piso y departamento opcionales. |
| 125 | link a login. |
| 126 | boton registrar. |

### Linea 132
- `toast` para mensajes de error o exito.

---

## 7. Explicacion detallada de `js/productos-api.js`

| Lineas | Explicacion |
|---|---|
| 1 y 2 | comentario que explica que este archivo concentra funciones reutilizables para productos. |
| 3 | `URL_API` guarda la base del backend. Si el back cambia de puerto o dominio, esta linea es de las primeras a tocar. |
| 5 a 10 | se crea un `Intl.NumberFormat`. Esto sirve para formatear cualquier numero como moneda argentina. |
| 6 | `style: "currency"` le dice que el valor se mostrara como dinero. |
| 7 | `currency: "ARS"` indica pesos argentinos. |
| 8 y 9 | controlan cuantos decimales mostrar. |
| 13 | `export async function obtenerProductos()` crea una funcion exportada y asincronica. `export` permite usarla desde otros archivos. `async` permite usar `await`. |
| 14 | `fetch(...)` hace la llamada HTTP real al backend. `await` frena la funcion hasta que llegue la respuesta. |
| 16 | `if (!respuesta.ok)` pregunta si la respuesta vino con error HTTP, por ejemplo 404, 500 o 400. |
| 17 | intenta leer el body del error como JSON. Si falla, usa `{}` para no romper. |
| 18 | arma un mensaje de error con prioridad: `message`, si no `error`, y si no un texto generico con el status. |
| 19 | `throw new Error(mensaje)` corta la ejecucion y manda el error al archivo que llamo esta funcion. |
| 22 | si todo salio bien, vuelve a leer la respuesta como JSON. |
| 23 | devuelve `cuerpo.data?.content ?? []`. Esto significa: “si existe `data.content`, devolvelo; si no, devolve un array vacio”. Aca se asume que el backend responde con una estructura paginada. |
| 27 | funcion para convertir cualquier numero en moneda visible. |
| 28 | `Number(valor) || 0` garantiza que siempre entre un numero. |
| 33 | `obtenerIdProducto(producto)` intenta sacar un identificador estable. |
| 34 a 36 | si el backend ya manda `id`, usa ese `id`. |
| 38 a 42 | si no existe `id`, arma uno artificial concatenando nombre, marca y foto. Eso evita que el carrito se rompa aunque el backend todavia no entregue id formal. |

### En union con backend
- Este archivo es el **puente base** para traer productos.
- Todo lo que sea “pedir productos” pasa por aca.

---

## 8. Explicacion detallada de `js/cart-store.js`

### Idea general
Este archivo no habla con el backend. Su trabajo es:
- guardar carrito en el navegador
- saber cuanto stock esta reservado en carrito
- saber cuanto stock ya fue “comprado” en este navegador
- calcular resúmenes que usan catalogo y checkout

### Explicacion por bloques

| Lineas | Explicacion |
|---|---|
| 1 | importa `obtenerIdProducto` para poder identificar productos siempre igual. |
| 4 a 6 | define nombres fijos para guardar datos en `localStorage` y para disparar un evento propio del carrito. |
| 9 a 16 | `leerStorage` intenta leer un valor del navegador. Si el JSON esta roto o no existe, devuelve un valor por defecto. |
| 18 a 20 | `guardarStorage` guarda cualquier objeto convirtiendolo a JSON string. |
| 22 a 36 | funciones internas especificas para leer/guardar carrito y stock comprado. Separarlas evita repetir claves hardcodeadas. |
| 38 a 40 | `normalizarCantidad` toma un valor cualquiera y lo transforma en entero no negativo. |
| 42 a 51 | `crearInstantaneaProducto` guarda una copia minima del producto dentro del carrito. Esto es util porque, aunque el backend cambie despues, el carrito conserva datos suficientes para mostrarse. |
| 53 a 59 | `emitirActualizacionCarrito` dispara un `CustomEvent` de navegador. Eso permite que otras pantallas se reactualicen al instante sin refrescar. |
| 62 a 64 | `obtenerItemsCarrito` expone el array crudo del carrito. |
| 66 a 69 | `obtenerCantidadComprada` mira en storage cuantas unidades ya quedaron marcadas como compradas. |
| 71 a 77 | `obtenerCantidadEnCarrito` busca un producto dentro del carrito y devuelve su cantidad actual. |
| 79 a 86 | `obtenerStockDisponible` calcula: `stock backend - cantidad comprada - cantidad actualmente en carrito`. Esto es la base del stock en tiempo real. |
| 89 a 127 | `agregarCantidadAlCarrito` valida y agrega unidades. |
| 92 a 97 | si la cantidad es 0 o invalida, devuelve error. |
| 99 | recalcula stock disponible real antes de agregar. |
| 101 a 106 | si no hay stock suficiente, devuelve error. |
| 108 a 111 | obtiene id, snapshot y lista actual del carrito. |
| 113 a 121 | si el producto ya existe, suma cantidad; si no existe, crea un item nuevo. |
| 124 y 125 | guarda el nuevo carrito y emite actualizacion. |
| 130 a 153 | `quitarCantidadDelCarrito` resta unidades. |
| 138 a 149 | usa `map` para modificar solo el item correcto y `filter` para eliminar los que queden en 0. |
| 155 a 163 | `quitarProductoDelCarrito` borra todas las unidades de un producto. |
| 166 a 211 | `construirResumenCarrito` arma un objeto ya listo para pintar en UI. |
| 167 a 169 | crea un `Map` de productos vivos traidos del backend, indexados por id. |
| 172 a 195 | transforma cada item del carrito en un producto resumen. |
| 174 y 175 | primero intenta usar el producto actual del backend; si no lo encuentra, usa la `instantanea` guardada en el carrito. |
| 181 y 182 | calcula cantidad y precio unitario. |
| 184 a 193 | devuelve un objeto limpio con `idProducto`, `nombre`, `marca`, `foto`, `descripcion`, `cantidad`, `precioUnitario`, `subtotal`. |
| 197 a 204 | calcula `total` en dinero y `totalUnidades` sumando todas las cantidades. |
| 214 a 239 | `finalizarPagoEnEfectivo` convierte las unidades del carrito en unidades compradas. |
| 217 a 222 | si el carrito esta vacio, corta. |
| 224 a 229 | suma la cantidad de cada producto al storage de stock comprado. |
| 231 y 232 | guarda ese stock comprado y limpia por completo el carrito. |
| 241 a 249 | `obtenerEstadoCarrito` devuelve el resumen general listo para otras pantallas. |
| 252 a 270 | `suscribirseAlCarrito` deja “escuchando” cambios del carrito. |
| 253 | prepara una funcion que avisa el estado actual al callback externo. |
| 254 a 261 | tambien escucha cambios de `storage`, por si el usuario modifica algo desde otra pestaña. |
| 263 a 265 | registra los listeners y dispara una primera actualizacion inmediata. |
| 267 a 270 | devuelve una funcion de limpieza para desuscribirse. |

### Donde se une despues con backend
- Hoy el carrito es local.
- Si mas adelante queres persistirlo en backend:
  - `agregarCantidadAlCarrito`
  - `quitarCantidadDelCarrito`
  - `quitarProductoDelCarrito`
  - `finalizarPagoEnEfectivo`
  serian los primeros puntos a reemplazar o complementar con `fetch`.

---

## 9. Explicacion detallada de `js/catalogo.js`

### Idea general
Este archivo hace casi toda la orquestacion del catalogo:
- pide productos al backend
- filtra productos
- dibuja tarjetas
- abre modal de detalle
- maneja el carrito flotante
- mantiene el stock en tiempo real usando `cart-store.js`

### Explicacion por bloques

| Lineas | Explicacion |
|---|---|
| 1 a 13 | imports. Trae funciones del carrito y de productos. Esto ya te muestra que `catalogo.js` no hace todo solo, sino que se apoya en modulos. |
| 16 a 18 | constantes de ruta y duracion de animaciones. |
| 21 a 32 | `estado` guarda el estado vivo de la pagina. Es el “cerebro” del catalogo. |
| 22 | `productos`: lista traida del backend. |
| 23 | `estadoCatalogo`: dice si todavia no cargo, si ya cargo o si hubo error. |
| 24 | `textoBusqueda`: lo que el usuario escribio en el buscador. |
| 25 | `idProductoActivo`: producto abierto en el modal. |
| 26 | `carritoAbierto`: true o false. |
| 27 y 28 | temporizadores para cierres animados. |
| 29 | producto que tiene abierto el panel para quitar cantidades. |
| 30 | mapa de borradores para cuantas unidades quiere quitar el usuario. |
| 31 | borrador de cuantas unidades quiere agregar desde el modal. |
| 35 a 59 | `elementos` cachea todos los nodos HTML importantes. Esto evita hacer `getElementById` una y otra vez. |
| 62 a 69 | `escaparHtml` evita inyectar texto peligroso en `innerHTML`. |
| 71 a 73 | `escaparRegex` sirve para que una busqueda con caracteres especiales no rompa la expresion regular. |
| 75 a 87 | `resaltarTexto` marca con `<span class="hl">` la coincidencia del buscador. |
| 90 a 109 | `obtenerProductosFiltrados` aplica el filtro de busqueda usando nombre, marca y descripcion. |
| 111 a 115 | `buscarProductoPorId` encuentra el producto real dentro del array ya cargado. |
| 117 a 121 | `obtenerProductoResumenCarrito` busca un producto dentro del resumen del carrito. |
| 123 a 145 | helpers para el borrador de cantidad que se va a quitar desde el carrito. |
| 147 a 163 | helpers para el borrador de cantidad que se va a agregar desde el modal. |
| 165 a 183 | abre y cierra internamente el editor de quitar cantidades por producto. |
| 185 a 187 | muestra u oculta el boton de limpiar busqueda segun haya texto o no. |
| 190 a 203 | `crearEstadoVacio` arma HTML reutilizable para “sin resultados” o “error”. |
| 205 a 212 | `mostrarErrorGrilla` usa ese estado vacio para mostrar error de carga. |
| 215 a 276 | `renderizarCatalogo` dibuja la grilla de productos. |
| 218 a 235 | si no hay productos filtrados, muestra mensaje vacio. |
| 238 a 275 | si hay productos, transforma cada uno en una tarjeta HTML. |
| 240 | obtiene el `idProducto`. |
| 241 | calcula stock disponible real usando el carrito y compras locales. |
| 242 | define si el producto puede agregarse o no. |
| 247 y 248 | guarda datos en `data-id-producto` y `data-puede-agregar` para usarlos despues desde eventos. |
| 261 a 263 | pinta nombre, marca y descripcion. |
| 266 | pinta precio formateado. |
| 267 y 268 | el boton cambia entre “Agregar al carrito” y “Sin stock”. |
| 279 a 412 | `renderizarCarrito` dibuja el panel flotante del carrito. |
| 280 | pide al store un resumen actualizado del carrito. |
| 282 a 284 | si el producto que estaba editandose ya no existe en carrito, cierra ese editor. |
| 286 a 288 | actualiza contador, total y estado del boton continuar. |
| 290 a 298 | si el carrito esta vacio, muestra mensaje vacio. |
| 300 a 411 | si hay productos, dibuja cada bloque del carrito. |
| 302 a 306 | decide si el panel de quitar esta abierto y con que cantidad. |
| 318 a 321 | boton del cesto con `data-accion` y `data-id-producto`. |
| 333 a 336 | muestra cantidad x precio unitario. |
| 340 y 341 | muestra subtotal por producto. |
| 345 a 407 | si el editor esta abierto, dibuja stepper + input + botones de quitar. |
| 415 a 450 | `sincronizarModalProducto` toma el producto activo y actualiza todo el modal. |
| 420 | busca el producto real por id. |
| 427 | recalcula stock real disponible. |
| 430 a 449 | actualiza imagen, textos, stock, precio, input de cantidad y estado de botones. |
| 452 a 460 | `abrirModalProducto` prepara estado, sincroniza datos, quita `hidden` y activa clase visual. |
| 462 a 482 | `cerrarModalProducto` hace el cierre animado del modal. |
| 485 a 514 | `abrirPanelCarrito`, `cerrarPanelCarrito` y `alternarPanelCarrito` hacen lo mismo para el panel flotante. |
| 517 a 522 | `reiniciarBusqueda` limpia el input y vuelve a renderizar. |
| 524 a 537 | `cargarProductos` es uno de los puntos clave de union con backend. |
| 526 | llama a `obtenerProductos()`. Aca el catalogo trae los productos del backend. |
| 527 | marca que el catalogo ya esta “listo”. |
| 528 a 530 | vuelve a pintar catalogo, carrito y modal con datos nuevos. |
| 531 a 535 | si falla el backend, muestra error. |
| 540 a 551 | click sobre una tarjeta: si puede agregarse, abre el modal del producto. |
| 553 a 569 | lo mismo pero con teclado Enter o barra espaciadora. |
| 571 a 614 | `manejarAccionesCarrito` interpreta las acciones del panel de carrito. |
| 577 | lee `accion` e `idProducto` desde `dataset`. |
| 584 a 612 | `switch` que decide si abrir editor, subir/bajar cantidad, aplicar quitar o quitar todo. |
| 616 a 635 | cuando el usuario escribe manualmente la cantidad a quitar, la normaliza y la corrige. |
| 637 a 646 | lo mismo pero para el input del modal de agregar. |
| 649 a 743 | `vincularEventos` registra todos los listeners de la pantalla. |
| 650 a 654 | evento `input` del buscador. |
| 656 | boton limpiar busqueda. |
| 657 y 658 | click y teclado en la grilla. |
| 659 a 663 | eventos del panel carrito. |
| 665 a 669 | boton continuar -> navega al checkout. |
| 671 a 677 | botones y click fuera del modal. |
| 679 a 699 | stepper de cantidad del modal. |
| 701 y 702 | eventos del input manual del modal. |
| 704 a 721 | boton “Agregar” del modal. |
| 710 a 715 | recalcula stock y llama a `agregarCantidadAlCarrito(producto, cantidadAAgregar)`. |
| 717 a 720 | si salio bien, reinicia cantidad y cierra modal. |
| 723 a 736 | click afuera del panel flotante -> cierra el carrito. |
| 738 a 742 | tecla Escape cierra el modal. |
| 745 a 761 | `iniciar()` arranca todo. |
| 746 | registra eventos. |
| 747 | acomoda el boton limpiar. |
| 749 a 756 | se suscribe a cambios del carrito. Cada vez que cambia, vuelve a renderizar catalogo, carrito y modal. |
| 758 | carga productos desde backend. |
| 761 | ejecuta el inicio real del archivo. |

### Como se une con el backend
- Union principal:
  - linea 526 -> `obtenerProductos()`
- Esa funcion viene de `productos-api.js`
- Flujo completo:
  - `catalogo.js` pide productos
  - `productos-api.js` hace `fetch`
  - el backend responde
  - el resultado vuelve a `catalogo.js`
  - `catalogo.js` renderiza las tarjetas

---

## 10. Explicacion detallada de `js/checkout.js`

| Lineas | Explicacion |
|---|---|
| 1 a 9 | imports del carrito y del modulo de productos. |
| 12 y 13 | ruta para volver al catalogo y duracion de animacion. |
| 16 a 19 | `estado` guarda productos cargados y temporizador de cierre del modal. |
| 21 a 30 | `elementos` cachea nodos del HTML. |
| 33 a 40 | `escaparHtml` protege los textos que van a `innerHTML`. |
| 43 a 87 | `renderizarCheckout` construye la pantalla. |
| 44 | pide un resumen listo del carrito. |
| 46 a 49 | actualiza cantidad, total, titulo del modal y habilitacion del boton pagar. |
| 51 a 60 | si el carrito esta vacio, muestra mensaje y link de vuelta. |
| 62 a 86 | si hay productos, dibuja cada uno en HTML. |
| 90 a 95 | abre el modal de pago. |
| 97 a 116 | cierra el modal de pago, con o sin animacion. |
| 118 a 127 | `cargarProductos` trae productos del backend indirectamente. |
| 120 | llamada real a `obtenerProductos()`. |
| 129 a 163 | listeners del checkout. |
| 131 a 135 | boton “Pagar en efectivo” abre modal. |
| 137 | boton cancelar cierra modal. |
| 139 a 150 | boton finalizar pago. |
| 140 | llama a `finalizarPagoEnEfectivo(estado.productos)`. |
| 142 a 146 | si el pago no puede cerrarse, re-renderiza. |
| 148 y 149 | si sale bien, cierra modal y vuelve al catalogo. |
| 152 a 156 | click fuera del modal tambien lo cierra. |
| 158 a 162 | Escape cierra el modal. |
| 165 a 171 | inicio del archivo. |
| 167 | suscribe la pantalla a cambios del carrito. |
| 168 | carga productos. |

### Como se une con el backend
- Igual que catalogo:
  - linea 120 -> `obtenerProductos()`
- El checkout no consulta backend por el pago.
- Hoy el “pago finalizado” es una confirmacion local en frontend.

---

## 11. Explicacion detallada de `js/ApiAdmin.js`

### Idea general
Este es el JS mas importante para explicar la union con backend del lado admin porque:
- trae productos existentes
- crea productos nuevos

### Explicacion por bloques

| Lineas | Explicacion |
|---|---|
| 2 | define la URL base del backend. |
| 3 | cuanto dura el toast. |
| 4 | HTML que se usa si no hay productos. |
| 5 | lista de ids del formulario. Sirve para recorrer campos sin repetir codigo. |
| 7 a 18 | cachea todo el DOM necesario de la pantalla. |
| 15 a 17 | `Object.fromEntries(...)` arma un objeto donde cada clave es el nombre del campo y el valor es el input real del DOM. |
| 21 a 28 | `escaparHtml` protege lo que se imprime en la tabla. |
| 30 a 35 | `mostrarToast` muestra mensajes temporales. |
| 37 a 47 | `extraerMensaje` sirve para leer errores del backend sin asumir siempre el mismo formato exacto. |
| 49 a 61 | `extraerErroresCampos` convierte errores detallados del backend en texto legible. |
| 64 a 72 | `activarPestana` prende y apaga clases `active` para mostrar el panel correcto. |
| 75 a 91 | `renderizarTabla` pinta la tabla de productos. |
| 76 a 79 | si no hay productos, muestra fila vacia. |
| 81 a 90 | si hay productos, arma cada fila usando nombre, marca, precio y stock. |
| 93 a 102 | `obtenerPayloadProducto` arma el objeto exacto que se va a mandar al backend. |
| 95 a 100 | toma valores del DOM, les hace `trim()` o parseo numerico y devuelve el objeto. |
| 104 a 126 | `validarFormularioProducto` valida antes de mandar al backend. |
| 128 a 132 | limpia todos los campos. |
| 134 a 138 | confirmacion al cancelar. |
| 140 a 160 | `cargarProductosAdmin` hace el `GET` al backend. |
| 142 | llamada real: `GET /api/productos?page=0&size=100` |
| 144 a 147 | si falla, intenta leer el error del backend y lo lanza. |
| 149 y 150 | si sale bien, lee JSON y obtiene `data.content`. |
| 151 | manda ese array a la tabla. |
| 152 a 159 | si hay error de red o de respuesta, dibuja una fila de error. |
| 163 a 200 | `crearProducto` hace el `POST` al backend. |
| 164 | arma el objeto `producto`. |
| 165 | valida antes de enviar. |
| 173 a 177 | llamada real al backend. |
| 174 | `method: "POST"` |
| 175 | header JSON |
| 176 | `JSON.stringify(producto)` convierte el objeto JS en texto JSON para enviar por HTTP. |
| 179 | intenta leer la respuesta del backend como JSON, incluso si vino error. |
| 181 a 190 | si el backend responde error, arma un mensaje combinando error principal + errores de campos. |
| 192 | toast de exito. |
| 193 | limpia formulario. |
| 194 | vuelve a pedir productos al backend para actualizar la tabla. |
| 195 | cambia de pestaña a la tabla. |
| 203 a 211 | registra los eventos de botones y pestañas. |
| 213 a 218 | inicio del archivo: registra eventos y hace la primera carga al backend. |

### Payload que se envia al backend al crear producto
```json
{
  "nombre": "...",
  "marca": "...",
  "precio": 123,
  "stock": 10,
  "foto": "https://...",
  "descripcion": "..."
}
```

### Este es uno de los puntos clave de union front-back
- `cargarProductosAdmin()` -> trae productos
- `crearProducto()` -> manda productos nuevos

---

## 12. Explicacion detallada de `js/RegistrarClienteApi.js`

### Idea general
Este archivo une el formulario de registro con el endpoint del backend que da de alta clientes.

### Explicacion por bloques

| Lineas | Explicacion |
|---|---|
| 2 | base del backend. |
| 3 | duracion del toast. |
| 5 a 21 | cachea todos los elementos del DOM. |
| 24 a 29 | `mostrarToast` muestra mensajes. |
| 31 a 41 | `extraerMensaje` lee el mensaje del backend. |
| 43 a 54 | `extraerErroresCampos` toma el primer error util si vienen varios. |
| 57 a 63 | `alternarVisibilidadContrasena` cambia `password` por `text` y alterna iconos. |
| 65 a 77 | `obtenerDatosFormulario` junta todos los datos escritos por el usuario. |
| 79 a 109 | `validarFormularioRegistro` valida cliente antes del POST. |
| 111 a 124 | `construirPayloadCliente` arma el objeto exacto que se manda al backend. |
| 113 | convierte DNI a numero. |
| 114 | une nombre y apellido en un solo campo `nombre`, porque asi lo espera el backend actual. |
| 119 a 122 | `piso` y `departamento` se mandan como `null` si no hay valor. |
| 127 a 164 | `registrarCliente` hace la llamada al backend. |
| 128 | obtiene datos del formulario. |
| 129 | valida en frontend. |
| 136 | arma `cliente` con el formato del backend. |
| 139 a 143 | `POST /api/clientes/register` con JSON. |
| 145 | intenta leer la respuesta del backend como JSON. |
| 147 a 152 | si el backend responde error, muestra el error de campo o el mensaje general. |
| 154 | guarda `data.data` del backend en `localStorage` con clave `cliente`. |
| 155 | muestra toast de exito. |
| 157 a 159 | redirige al catalogo despues de 1,2 segundos. |
| 166 a 174 | registra eventos de click y submit. |
| 176 a 180 | inicio del archivo. |

### Payload que se envia al backend al registrar
```json
{
  "dni": 12345678,
  "nombre": "Juan Perez",
  "email": "juan@email.com",
  "password": "clave123",
  "localidad": "Ciudad",
  "provincia": "Cordoba",
  "piso": 3,
  "departamento": "A"
}
```

### Este es el punto clave de union front-back en registro
- `registrarCliente()` es la funcion central.
- Si el backend cambia nombres de campos o endpoint, este archivo es uno de los primeros a revisar.

---

## 13. Resumen final: que archivos tocas segun el caso

### Si queres cambiar como se piden productos al backend
- `js/productos-api.js`

### Si queres cambiar como se crea un producto
- `js/ApiAdmin.js`

### Si queres cambiar como se registra un cliente
- `js/RegistrarClienteApi.js`

### Si queres cambiar como se pinta el catalogo
- `pages/CatalogoCliente.html`
- `js/catalogo.js`

### Si queres cambiar como se comporta el carrito
- `js/cart-store.js`
- `js/catalogo.js`
- `js/checkout.js`

### Si queres conectar el pago o el carrito al backend de verdad
- primero `js/cart-store.js`
- despues `js/checkout.js`

---

## 14. Glosario rapido para explicarlo a tus compañeros

- `fetch`: hace una peticion HTTP.
- `await`: espera a que una promesa termine.
- `async`: permite usar `await`.
- `response.ok`: dice si la respuesta HTTP fue exitosa.
- `JSON.stringify(objeto)`: convierte un objeto JS a texto JSON para enviarlo al backend.
- `response.json()`: convierte la respuesta del backend en objeto JS.
- `localStorage`: memoria del navegador que queda guardada aunque recargues.
- `dataset`: forma de leer atributos `data-*` de un elemento HTML.
- `innerHTML`: reemplaza el contenido interno de un nodo con HTML armado como string.
- `addEventListener`: conecta un evento con una funcion.
- `preventDefault()`: evita el comportamiento normal del navegador.
- `CustomEvent`: evento propio creado por la aplicacion.
- `Map`: estructura clave-valor mas comoda para buscar rapido por id.

---

## 15. Idea simple para exponer la arquitectura

Podes explicarlo asi:

1. El HTML define los contenedores vacios y los botones.
2. Los JS buscan esos contenedores por `id`.
3. `productos-api.js` trae datos del backend.
4. `catalogo.js` y `checkout.js` usan esos datos para pintar la pantalla.
5. `cart-store.js` guarda el carrito localmente y recalcula stock.
6. `ApiAdmin.js` y `RegistrarClienteApi.js` son los archivos que hacen `POST` al backend.
7. Si cambia el contrato del backend, los puntos mas sensibles son:
   - `js/productos-api.js`
   - `js/ApiAdmin.js`
   - `js/RegistrarClienteApi.js`

